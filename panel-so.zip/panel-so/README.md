# Panel de Simuladores · Sistemas Operativos

Panel único que reúne 4 simuladores interactivos de Sistemas Operativos:

**Gestión de memoria**
- `algoritmos/fifo.html` — Reemplazo de páginas FIFO
- `algoritmos/lfu.html` — Reemplazo de páginas LFU

**Planificación de CPU**
- `algoritmos/prioridad.html` — Prioridad no expropiativo
- `algoritmos/round-robin.html` — Round Robin

Cada simulador conserva su código original intacto y corre de forma aislada
dentro de un `iframe`. `index.html` es solo el panel de navegación: una
barra lateral que carga el simulador elegido, con enlaces directos vía hash
(por ejemplo `index.html#lfu` abre LFU directamente).

## Estructura

```
panel-so/
├── index.html                  ← panel de control (punto de entrada)
└── algoritmos/
    ├── fifo.html
    ├── lfu.html
    ├── prioridad.html
    └── round-robin.html
```

## Cómo subirlo a GitHub

1. Crea un repositorio nuevo en GitHub (sin README, para evitar conflictos),
   por ejemplo `panel-simuladores-so`.

2. En tu máquina, dentro de la carpeta `panel-so`, ejecuta:

```bash
git init
git add .
git commit -m "Panel de control unificado - simuladores SO"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/panel-simuladores-so.git
git push -u origin main
```

Reemplaza `TU_USUARIO` y el nombre del repo por los tuyos.

## Publicarlo con GitHub Pages (para verlo online)

1. En el repo, ve a **Settings → Pages**.
2. En "Source", elige la rama `main` y la carpeta `/ (root)`.
3. Guarda. En unos minutos tu panel estará disponible en:
   `https://TU_USUARIO.github.io/panel-simuladores-so/`

No necesitas build ni backend: son solo archivos estáticos.

## Notas

- Si agregas un nuevo simulador después, solo tienes que:
  1. Copiar el `.html` a `algoritmos/`.
  2. Agregar un nuevo `<button class="proc-row">` en el sidebar de `index.html`,
     con su `data-src` apuntando al archivo.
- Los simuladores no comparten variables entre sí (cada uno vive en su propio
  iframe), así que no hay riesgo de que uno rompa a otro.
